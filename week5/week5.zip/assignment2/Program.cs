﻿using System;

namespace assignment2
{
    class Program
    {
        static void Main(string[] args)
        {
            Program main = new Program();
            main.Start();
        }

        void Start()
        {

        }
    }
}
